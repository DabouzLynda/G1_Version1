import {ChangeDetectionStrategy, Component, Input, OnInit} from '@angular/core';
import {TodoListWithItems, TodoListService} from "../todo-list.service";


@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TodoListComponent implements OnInit {
  @Input() list: TodoListWithItems;
  @Input() clock: number;

  currentListItem = -1;
  filtre = "";

  constructor(private todoListService: TodoListService) { }

  ngOnInit() {
  }

  createItem(label: string, participants: string, dateI: string) {
  if(label == ""){
  alert("L'item doit avoir un nom.");
  } else {
    const localIdItem = this.todoListService.SERVER_CREATE_ITEM(
      this.list.id,
      label,
      false,
      {participants: participants.split(",").map( P => P.trim()), dateI}
    );
    }
  }


  getColor(): string {
    return this.list.data["color"] ? this.list.data["color"] : "#FFFFFF";
  }

  setColor(color: string) {
    console.log("setColor", color);
    this.todoListService.SERVER_UPDATE_LIST_DATA(
      this.list.id,
      Object.assign({}, this.list.data, {color})
    );
  }

  trier(){
    (this.list as any).sort(function(a,b){
  // Turn your strings into dates, and then subtract them
  // to get a value that is either negative, positive, or zero.
  //return new Date(b.date) - new Date(a.date);
});
  }
}
